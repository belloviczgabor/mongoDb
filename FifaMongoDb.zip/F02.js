//2.feladat: Az előbb létrehozzott kollekciójába helyezze el a txt államányban található adatokat, dokumentumokban rendezve, az állományban az összetartozó adatok soronként vannak elhelyezve, elválasztó karakterük pedig ";"!
//Csapat
//Helyezes
//Valtozas
//Pontszam

//KESZ

var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://gaboriusz:Maci0814@cluster0.usqpjnx.mongodb.net/"//T13

async function AdatBeillesztes() {
    try {
        const client = await MongoClient.connect(url);
        const db = client.db("T13");
        const collection = db.collection("Fifa")

        let fifa = [
            "Anglia;4;0;1662",
            "Argentína;10;0;1614",
            "Belgium;1;0;1752",
            "Brazília;3;-1;1719",
            "Chile;17;-3;1576",
            "Dánia;14;-1;1584",
            "Franciaország;2;1;1725",
            "Hollandia;13;3;1586",
            "Horvátország;8;-1;1625",
            "Kolumbia;9;-1;1622",
            "Mexikó;12;0;1603",
            "Németország;16;-1;1580",
            "Olaszország;15;1;1583",
            "Peru;19;0;1551",
            "Portugália;5;1;1643",
            "Spanyolország;7;2;1631",
            "Svájc;11;0;1604",
            "Svédország;18;0;1560",
            "Szenegál;20;0;1546",
            "Uruguay;6;-1;1639",
        ]

        function ObjektumFeltolto(feltoltendoElem) {
            let beolvasottAdatok = [];
            for (let i = 0; i < feltoltendoElem.length; i++) {
                let objektum = {};
                let daraboltAdatSor = feltoltendoElem[i].split(";");
                objektum.Csapat = daraboltAdatSor[0];
                objektum.Helyezes = Number(daraboltAdatSor[1]);
                objektum.Valtozas = Number(daraboltAdatSor[2]);
                objektum.Pontszam = Number(daraboltAdatSor[3]);
                beolvasottAdatok.push(objektum);
            }
            return beolvasottAdatok;
        }
        let fifaAdatok = ObjektumFeltolto(fifa);

        const muveletek = await collection.insertMany(fifaAdatok)
        console.log("Dokumentumok feltoltese sikeres:", muveletek.insertedCount, "adat feltoltesre kerult!")
        client.close()
    }


    catch (err) {
        console.log("Hiba tortent a csatlakozas vagy beszuras kozben:", err)
    }
}
AdatBeillesztes()