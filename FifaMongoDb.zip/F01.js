//1.feladat: Hozzon létre egy kollekciót "Fifa" néven.MongoDB segítségével, Atlas felhőszolgáltatásba!

//KESZ

var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://gaboriusz:Maci0814@cluster0.usqpjnx.mongodb.net/"//T13

async function kollekcioLetrehozas() {
    try {
        const client = await MongoClient.connect(url)
        const db = client.db("T13");
        await db.createCollection("Fifa")
        console.log("A mintaKollekcio a T13 adatbazisban letrejott")
        client.close()
    }
    catch (err) {
        console.error("Hiba tortent a kollekcio letrehozasa soran:", err)
    }
}
kollekcioLetrehozas()