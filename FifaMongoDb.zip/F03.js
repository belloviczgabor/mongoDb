//3.feladat: Mivel alapnak ABC rendben vannak a csapatok, ami nekünk nem megfelelő, rendezze immáron pontszám szerint őket, csupán a csapat neve és a helyezése jelenjen meg, pontszám szerint csökennő sorban...
//KESZ

var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://gaboriusz:Maci0814@cluster0.usqpjnx.mongodb.net/"//T13

async function Rendezes() {
    try {
        const client = await MongoClient.connect(url);
        const db = client.db("T13")
        const collection = db.collection("Fifa")

        const rendezesBeallitasi = { Pontszam: 1 }
        const eredmeny = await collection.find({}, { projection: { _id: 0, Csapat: 1, Helyezes: 1 } }).sort(rendezesBeallitasi).toArray()

        console.log(eredmeny)
        client.close()
    }
    catch (err) {
        console.error("Hiba a muvelet vegrahajtasa kozben", err)
    }
}
Rendezes()