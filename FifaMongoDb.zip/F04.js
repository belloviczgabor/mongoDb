//4.feladat: Jelenítse meg a legjobb 3 csapat minden adatát! Helyezésük alapján rendezve.
//KESZ

var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://gaboriusz:Maci0814@cluster0.usqpjnx.mongodb.net/"//T13

async function Legjobb3Csapat() {
    try {
        const client = await MongoClient.connect(url);
        const db = client.db("T13")
        const collection = db.collection("Fifa")


        const rendezesBeallitasi = { Helyezes: 1 }

        const eredmeny = await collection.find().sort(rendezesBeallitasi).limit(3).toArray();
        console.log(eredmeny)
        client.close()
    }
    catch (err) {
        console.error("Hiba a muvelet vegrahajtasa kozben", err)
    }
}
Legjobb3Csapat()