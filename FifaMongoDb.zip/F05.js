//5.feladat: Listázza ki azoknak a csapatoknak a nevét, amik az előző alkalom óta helyezésük nem változott!

//KESZ

var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://gaboriusz:Maci0814@cluster0.usqpjnx.mongodb.net/"//T13

async function NincsValtozas() {
    try {
        const client = await MongoClient.connect(url);
        const db = client.db("T13")
        const collection = db.collection("Fifa")

        const lekerdezesEredmenyei = await collection.find({
            Valtozas: {
                $in: [0]
            }
        }, { projection: { _id: 0, Csapat: 1 } }).toArray();

        console.log(lekerdezesEredmenyei);

        client.close()
    }
    catch (err) {
        console.error("Hiba a muvelet vegrahajtasa kozben", err)
    }
}
NincsValtozas()