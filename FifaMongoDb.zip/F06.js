//6.feladat: Jelenítse meg azoknak a csapatoknak a nevét és pontszámát, akik 1600 pontnál többet szereztek

//KESZ

var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://gaboriusz:Maci0814@cluster0.usqpjnx.mongodb.net/"//T13

async function TobbMint1600pont() {
    try {
        const client = await MongoClient.connect(url);
        const db = client.db("T13")
        const collection = db.collection("Fifa")


        const eredmeny = await collection.find({ Pontszam: { $gt: 1600 } }, { projection: { _id: 0, Csapat: 1, Pontszam: 1 } }).toArray();


        console.log("Az 1600 pont feletti csapatok:", eredmeny)
        client.close()
    }
    catch (err) {
        console.error("Hiba a muvelet vegrahajtasa kozben", err)
    }
}
TobbMint1600pont()