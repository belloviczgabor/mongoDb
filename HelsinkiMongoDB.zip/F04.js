//Listázd ki azokat a versenyszámokat, ahol dobogós helyezést ért el a magyar csapat.

//kesz

var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://gaboriusz:Maci0814@cluster0.usqpjnx.mongodb.net/"//T13

async function DobogosHelyezesek() {
    try {
        const client = await MongoClient.connect(url);
        const db = client.db("T13")
        const collection = db.collection("Helsinki")

        //A findnak adhatunk meg parametert
        const eredmeny = await collection.find({ Helyezes: { $lte: 3 } }, { projection: { _id: 0, Sportag: 1 } }).toArray();


        console.log("Ezek a versenyszamok ertek el dobogos helyezest:", eredmeny)
        client.close()
    }
    catch (err) {
        console.error("Hiba a muvelet vegrahajtasa kozben", err)
    }
}
DobogosHelyezesek()