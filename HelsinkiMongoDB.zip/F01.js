//Hozzon létre egy kollekciót "Helsinki" néven. MongoDB segítségével, Atlas felhőszolgáltatásba!

//kesz


var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://gaboriusz:Maci0814@cluster0.usqpjnx.mongodb.net/"//T13

async function UjKollekcio() {
    try {
        const client = await MongoClient.connect(url)
        const db = client.db("T13");
        await db.createCollection("Helsinki")
        console.log("A HelsinkiKollekcio a T13 adatbazisban letrejott")
        client.close()
    }
    catch (err) {
        console.error("Hiba tortent a kollekcio letrehozasa soran:", err)
    }
}
UjKollekcio()