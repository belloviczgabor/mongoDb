//Listázd ki azokat a sportágakat, amikben egyéniben szereztek a magyarok aranyérmet.

//kesz

var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://gaboriusz:Maci0814@cluster0.usqpjnx.mongodb.net/"//T13

async function AranyErmek() {
    try {
        const client = await MongoClient.connect(url);
        const db = client.db("T13")
        const collection = db.collection("Helsinki")


        const eredmeny = await collection.find({ Helyezes: { $lt: 2 } }, { projection: { _id: 0, Sportag: 1 } }).toArray();


        console.log("Ezekben a versenyszamokban szereztek a magyarok aranyermet:", eredmeny)
        client.close()
    }
    catch (err) {
        console.error("Hiba a muvelet vegrahajtasa kozben", err)
    }
}
AranyErmek()