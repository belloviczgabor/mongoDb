//Jelenítsd meg a legnagyobb csapatmérettel rendelkező versenyszám csapatának minden adatát.

//kesz

var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://gaboriusz:Maci0814@cluster0.usqpjnx.mongodb.net/"//T13

async function LegnagyobbCsapatmeret() {
    try {
        const client = await MongoClient.connect(url);
        const db = client.db("T13")
        const collection = db.collection("Helsinki")

        const rendezesBeallitasi = { Csapatmeret: -1 }
        const eredmeny = await collection.find().sort(rendezesBeallitasi).limit(1).toArray();

        console.log(eredmeny)
        client.close()

    }
    catch (err) {
        console.error("Hiba a muvelet vegrahajtasa kozben", err)
    }
}
LegnagyobbCsapatmeret()