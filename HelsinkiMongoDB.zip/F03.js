//Listázza ki az azokat a sportágakat, amik torna vagy úszás sportágból vannak. A megjelenített adatokból, csak a sportág neve és a versenyszám neve látszódjon.

var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://gaboriusz:Maci0814@cluster0.usqpjnx.mongodb.net/"//T13

async function UszasVagyTorna() {
    try {
        const client = await MongoClient.connect(url);
        const db = client.db("T13");
        const collection = db.collection("Helsinki");

        const lekerdezesEredmenyei = await collection.find({
            $or: [{
                Sportag: "uszas"
            },
            {
                Sportag: "torna"
            }
            ]
        }, { projection: { _id: 0, Sportag: 1, Versenyszam: 1 } }).toArray();

        console.log(lekerdezesEredmenyei);
        client.close();
    }
    catch (err) {
        console.error("Hiba a művelet végrehajtása közben.", err);
    }
}
UszasVagyTorna()